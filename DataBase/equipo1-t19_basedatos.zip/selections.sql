SELECT * FROM users;
SELECT * FROM teachers;
SELECT * FROM subjects;
select * from user_subjects;
select * from teacher_grades;
select * from subject_grades;
