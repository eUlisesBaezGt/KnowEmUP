INSERT INTO users(studentID,progress_id,username,fname,lname,email,password,faculty,carreer,semester )
  VALUES('0246757','Prog_0246757','kenji7','Kenji','Minemura','0246757@up.edu.mx','Kenji0246757','ING','Ingeniería en Inteligencia de Datos y Ciberseguridad','3'), 
  ('0241823','Prog_0241823','enrique3','Enrique','Baez','0241823@up.edu.mx','Enrique0241823','ING','Ingeniería en Inteligencia de Datos y Ciberseguridad','3'), 
  ('0249220','Prog_0249220','mauricio0','Mauricio','Martinez','0249220@up.edu.mx','Mauricio0249220','ING','Ingeniería en Inteligencia de Datos y Ciberseguridad','3'), 
  ('0244643','Prog_0244643','sara3','Sara','Miranda','0244643@up.edu.mx','Sara0244643','ING','Ingeniería en Inteligencia de Datos y Ciberseguridad','3'), 
  ('0247877','Prog_0247877','angel7','Angel','Esqueda','0247877@up.edu.mx','Angel0247877','ING','Ingeniería en Inteligencia de Datos y Ciberseguridad','3'), 
  ('0243250','Prog_0243250','daniela0','Daniela','Aguilera','0243250@up.edu.mx','Daniela0243250','ING','Ingeniería Mecánica','3'), 
  ('0246717','Prog_0246717','andoreni7','Andoreni','Flores','0246717@up.edu.mx','Andoreni0246717','ING','Ingeniería Mecatrónica','3'), 
  ('0243377','Prog_0243377','diego7','Diego','Cazares','0243377@up.edu.mx','Diego0243377','ING','Ingeniería Mecatrónica','3'), 
  ('0246726','Prog_0246726','alejandro6','Alejandro','Mondragon','0246726@up.edu.mx','Alejandro0246726','ING','Ingeniería en Innovación y Diseño','1'), 
  ('0245541','Prog_0245541','diego1','Diego','Herrera','0245541@up.edu.mx','Diego0245541','ING','Ingeniería Mecánica','3');